files in this folder are required for compilation and in order to avoid conflicts they should go in

	{railo-builder-website}/WEB-INF/lib/compile